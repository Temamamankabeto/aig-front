export * from "./table.type";
